package kl.wof.biz.sign;

import java.security.MessageDigest;
import java.security.Signature;
import java.util.Arrays;

import kl.wof.AppPage;

import org.apache.commons.codec.binary.Base64;

import kl.security.asn1.OctetString;
import kl.security.pki.pkcs7.ContentInfo;
import kl.security.pki.pkcs7.SignedData;
import kl.security.pki.pkcs7.SignerInfo;
import kl.security.pki.pkcs9.Identifiers;
import kl.security.pki.x501.Attribute;
import kl.security.pki.x509.Certificate;

public class RsaSignExec implements ISignExec {

	private static final long serialVersionUID = 1L;

	@Override
	public void verifySign(AppPage page, Certificate cert, String originData,
			String b64SignedData) throws Exception {
		ContentInfo ci = new ContentInfo();
		ci.decode(Base64.decodeBase64(b64SignedData));
		SignedData sd = (SignedData) ci.getContent().getActual();
		// ��ȡԭ��
		byte[] sourceData;
		OctetString data = (OctetString) sd.getContentInfo().getContent()
				.getActual();
		sourceData = (byte[]) data.getValue();
		new String(sourceData, "UTF-16LE");
		if (sourceData == null) {
			// P7����δ����ԭ��
			sourceData = originData.getBytes();
		}
		// ��֤���̰���2�����棺1��ͨ��ԭ�ļ���ժҪ�ʹ�ǩ��ֵ�����Ա�
		// 2����֤ǩ������Ƿ�ΪTrue
		SignerInfo si = sd.getSignerInfo(0);
		// ԭ��ժҪ
		byte[] digestBytes = null;
		for (int i = 0; i < si.getAuthenticatedAttributes().getComponentCount(); i++) {
			Attribute att = (Attribute) si.getAuthenticatedAttributes()
					.getComponent(i);
			if (att.getType().equals(Identifiers.messageDigest)) {
				OctetString os = (OctetString) att.getAttributeValue(0);
				digestBytes = (byte[]) os.getValue();
				break;
			}
		}
		// ����ԭ��ժҪ

		byte[] calculateDigest;
		MessageDigest messageDigest = MessageDigest.getInstance("SHA-1");
		messageDigest.update(sourceData);
		calculateDigest = messageDigest.digest();
		// ��֤ԭ���Ƿ񱻴���
		if (!Arrays.equals(digestBytes, calculateDigest)) {
			throw new Exception("ԭ�ı�����");
		}

		// ��ǩ��ֵ
		byte[] beSigBytes = si.getTobeSignedAuthenticatedAttributesEncoded();
		// ǩ�����
		byte[] sigBytes = (byte[]) si.getEncryptedDigest().getValue();
		// Ӧͨ���㷨OIDƴ��ǩ���㷨���˴�ӦΪԼ�����ˣ�����д��SHA1WITHRSA
		// logger.debug(si.getDigestAlgorithm().getAlgorithm().toString());
		// logger.debug(si.getDigestEncryptionAlgorithm().getAlgorithm().toString());
		Signature sig = Signature.getInstance("SHA1WITHRSA");
		sig.initVerify(cert.getPublicKey());
		sig.update(beSigBytes);
		if (!sig.verify(sigBytes)) {
			throw new Exception("ǩ����֤ʧ��");
		}
	}

	@Override
	public int getDeviceType(AppPage page) {
		return 1;
	}

}
